/*global angular */

/**
 * The main controller for the app. The controller:
 * - retrieves and persists the model via the todoStorage service
 * - exposes the model to the template and provides event handlers
 */
angular.module('todomvc')
	.controller('TodoCtrl', function TodoCtrl($scope, $routeParams,$http,$filter) {
		'use strict';

		var todos;
		$scope.todos;

		$scope.newTodo = '';
		$scope.editedTodo = null;

		
		$scope.getTodoDetails = function () {
		console.log("getTodoDetails called");
		$http.get("http://localhost:8080/api/todos")
			.then(function (response) {
				$scope.todos = response.data;
				todos = $scope.todos;
				console.log($scope.todos);
				$scope.$watch('todos', function () {
					$scope.remainingCount = $filter('filter')(todos, { completed: false }).length;
					$scope.completedCount = todos.length - $scope.remainingCount;
					$scope.allChecked = !$scope.remainingCount;
				}, true); 
		});
		}

		// Monitor the current route for changes and adjust the filter accordingly.
		$scope.$on('$routeChangeSuccess', function () {
			$scope.getTodoDetails();
			console.log("routeChangeSuccess");
			var status = $scope.status = $routeParams.status || '';
			$scope.statusFilter = (status === 'active') ?
				{ completed: false } : (status === 'completed') ?
				{ completed: true } : {};
		});

		$scope.addTodo = function () {
			
			var newTodo = {
				title: $scope.newTodo.trim(),
				completed: false
			};

			console.log(newTodo);

			if (!newTodo.title) {
				return;
			}

			$scope.saving = true;
			$http({
					method: 'POST',
					url: "http://localhost:8080/api/todos",
					headers: {
						'Content-Type': 'application/json'
					},
					data: newTodo
				})
				.success(function (data, status, headers, config) {
					$scope.newTodo = '';
					$scope.saving = false;
					$scope.getTodoDetails();					
					console.log("added");
					})
				.error(function (data, status, headers, config) {
					console.log("Device Addition failed");
					console.log(data);					
					$scope.saving = false;
			});
			/* store.insert(newTodo)
				.then(function success() {
					$scope.newTodo = '';
				})
				.finally(function () {
					$scope.saving = false;
				}); */
		
		};

		$scope.editTodo = function (todo) {
			console.log("editedTodo");
			$scope.editedTodo = todo;
			// Clone the original todo to restore it on demand.
			$scope.originalTodo = angular.extend({}, todo);
		};

		$scope.saveEdits = function (todo, event) {
			// Blur events are automatically triggered after the form submit event.
			// This does some unfortunate logic handling to prevent saving twice.
			if (event === 'blur' && $scope.saveEvent === 'submit') {
				$scope.saveEvent = null;
				return;
			}

			$scope.saveEvent = event;

			if ($scope.reverted) {
				// Todo edits were reverted-- don't save.
				$scope.reverted = null;
				return;
			}

			todo.title = todo.title.trim();

			if (todo.title === $scope.originalTodo.title) {
				$scope.editedTodo = null;
				return;
			}
			
			todo.title = $scope.originalTodo.title;
			$http({
					method: 'PUT',
					url: "http://localhost:8080/api/todos/" + todo.id,
					headers: {
						'Content-Type': 'application/json'
					},
					data: todo
				})
				.success(function (data, status, headers, config) {					
					//todo.title = $scope.originalTodo.title;
					console.log("saveEdits");
					//$scope.getTodoDetails();
					})
				.error(function (data, status, headers, config) {
					$scope.editedTodo = null;
					console.log("Todo save failed");					
			});
			
		};

		$scope.revertEdits = function (todo) {
			todos[todos.indexOf(todo)] = $scope.originalTodo;
			$scope.editedTodo = null;
			$scope.originalTodo = null;
			$scope.reverted = true;
		};

		$scope.removeTodo = function (todo) {
			console.log("removeTodo called");
			$http({
					method: 'DELETE',
					url: "http://localhost:8080/api/todos/" + todo.id,
					headers: {
						'Content-Type': 'application/json'
					},
					data: todo
				})
				.success(function (data, status, headers, config) {	
					$scope.getTodoDetails();				
					})
				.error(function (data, status, headers, config) {
					console.log("Todo delete failed");					
			});
		};

		$scope.saveTodo = function (todo) {
			console.log("saveTodo called");
			$http({
					method: 'PUT',
					url: "http://localhost:8080/api/todos/" + todo.id,
					headers: {
						'Content-Type': 'application/json'
					},
					data: todo
				})
				.success(function (data, status, headers, config) {					
					$scope.getTodoDetails();
					})
				.error(function (data, status, headers, config) {
					console.log("Todo save failed");					
			});
		};

		$scope.toggleCompleted = function (todo, completed) {
			if (angular.isDefined(completed)) {
				todo.completed = completed;
			}
			
			$http({
					method: 'PUT',
					url: "http://localhost:8080/api/todos/" + todo.id,
					headers: {
						'Content-Type': 'application/json'
					},
					data: todo
				})
				.success(function (data, status, headers, config) {
					todo.completed = !todo.completed;
					console.log("toggleCompleted completed");
					$scope.getTodoDetails();
					})
				.error(function (data, status, headers, config) {
					console.log("Todo Update failed");					
			});
		};

		$scope.clearCompletedTodos = function () {
			$http({
					method: 'DELETE',
					url: "http://localhost:8080/api/todos/clearcompleted",
					headers: {
						'Content-Type': 'application/json'
					},
					data: ""
				})
				.success(function (data, status, headers, config) {
					$scope.getTodoDetails();
					})
				.error(function (data, status, headers, config) {
					console.log("Todo Update failed");					
			});
		};

		$scope.markAll = function (completed) {
			console.log("markAll");
			todos.forEach(function (todo) {
				if (todo.completed !== completed) {
					$scope.toggleCompleted(todo, completed);
				}
			});
		};
	});
